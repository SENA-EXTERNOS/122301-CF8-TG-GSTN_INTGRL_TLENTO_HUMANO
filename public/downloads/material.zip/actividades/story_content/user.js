function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Voa7TRm0D3":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

